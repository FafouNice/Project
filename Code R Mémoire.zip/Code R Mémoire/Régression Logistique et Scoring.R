
setwd("C:/Users/x168165/Desktop/B_D")
#REG LINEAIRE MULTIPLE
install.packages("ggcorrplot")


install.packages("XML")
install.packages("reshape2")
install.packages("plyr")
install.packages("ggplot2")
library(microbenchmark)

library(FSelectorRcpp)
library(installr)
library(RWeka)
library(Amelia)
library(scales)

library(XML)
library(reshape2)
library(plyr)
library(ggplot2)
source('http://klein.uk/R/Viz/pyramids.R')
require(RODBC)
library(sqldf)
install.packages("devtools")
devtools::install_github("ramnathv/rCharts")
library(rCharts)

install.packages("dplyr")
library(dplyr)


Base_Emprnt= read.csv(file.choose(),sep=";")

Claims=read.csv(file.choose(),sep=";")


nrow(Base_Emprnt)
head(Base_Emprnt)
str(Base_Emprnt)
names(Base_Emprnt)
summary(Base_Emprnt)

#  gestion des Na dans les colonnes primes 
Base_Emprnt$Primes.2011[is.na(Base_Emprnt$Primes.2011)] <- 0
Base_Emprnt$Primes.2012[is.na(Base_Emprnt$Primes.2012)] <- 0
Base_Emprnt$Primes.2013[is.na(Base_Emprnt$Primes.2013)] <- 0
Base_Emprnt$Primes.2014[is.na(Base_Emprnt$Primes.2014)] <- 0
Base_Emprnt$Primes.2015[is.na(Base_Emprnt$Primes.2015)] <- 0

#Recodage des variables: Pour faire une analyse des variables quantitatives et qualitatives

Base_Emprnt$INSURED_BIRTHDATE<-as.Date(Base_Emprnt$INSURED_BIRTHDATE,format="%d/%m/%Y")             #Chgt de format pour les dates
Base_Emprnt$CONTRACT_EFECTIVE_DATE<-as.Date(Base_Emprnt$CONTRACT_EFECTIVE_DATE,format="%d/%m/%Y")   #Chgt de format pour les dates

Base_Emprnt$THEORETICAL_ENDING_DATE<-as.Date(Base_Emprnt$THEORETICAL_ENDING_DATE,format="%d/%m/%Y")



#Cr�ation d'une variable Prime totale

Base_Emprnt$Prime.Totale= Base_Emprnt$Primes.2011+Base_Emprnt$Primes.2012+Base_Emprnt$Primes.2013+Base_Emprnt$Primes.2014+Base_Emprnt$Primes.2015




#  S�paration des  variables quantitaives et qualitatives

ind.quant <- sapply(Base_Emprnt, function(x) is.numeric(x) | is.integer(x))

ind.qual <- sapply(Base_Emprnt, function(x) is.factor(x))

# variables quantitatives
Base_Emprnt.quant <- Base_Emprnt[ ,ind.quant]

s=summary(Base_Emprnt.quant)

write.csv(s,File="Summary.csv")

missmap(Base_Emprnt.quant, col=c("red", " pink"), legend=FALSE)

library(reshape2)
library(ggplot2)
library(dplyr)
ggplot_missing(Base_Emprnt.quant)
# variables qualitatives
Base_Emprnt.qual <- Base_Emprnt[ ,ind.qual]


# ANALYSE STATISTIQUE  des variables qualitatives: Analyse graphique

#  analyse de la variable Sexe

summary(Base_Emprnt$Sexe)


set.seed(1234)

Plot1=ggplot(data=Base_Emprnt, aes(x=Sexe,fill=Sexe)) +
  
geom_bar(stat="count")

Plot1+expand_limits(y=c(0,500000))

Plot1 + scale_y_continuous(labels = scientific)


# Changer la couleur des traits par groupe

library(plyr)
mu <- ddply(Base_Emprnt, "Base_Emprnt$Sexe", summarise, grp.mean=mean(Base_Emprnt$Age))
head(mu)
p=ggplot(Base_Emprnt, aes(x=Age, color=Sexe)) +
  geom_density(alpha=1)
p + theme(legend.position="top")



colors<-c("gray","lightgreen","darkred")

# Histogramme avec courbe de distribution
ggplot(Base_Emprnt, aes(x=Age)) + 
  geom_histogram(aes(y=..density..), colour="black", fill="white")+
  geom_density(alpha=.2, fill="#FF6666") 
# Couleur par groupes
ggplot(Base_Emprnt, aes(x=Age, color=Sexe, fill=Sexe)) + 
  geom_histogram(aes(y=..density..), alpha=0.5, 
                 position="identity")+
  geom_density(alpha=.2) 


pie(table(Base_Emprnt$STATUS_AT_THE_CLOSING_DATE),col=colors,main="R�partition de la consommation de tabac",
    labels=round(table(Base_Emprnt$STATUS_AT_THE_CLOSING_DATE)/nrow(Base_Emprnt),digits=3))
legend("bottomleft", xpd = TRUE, legend = unique(Base_Emprnt$STATUS_AT_THE_CLOSING_DATE),fill=colors)

cas$cut.age <- cut(cas$age,seq(0,100,10))
ggplot(data = Base_Emprnt, aes(x = Age, fill =Base_Emprnt$Sexe)) + 
  geom_bar(data = subset(Base_Emprnt,Base_Emprnt$Sexe == "H")) + 
  geom_bar(data = subset(Base_Emprnt, Base_Emprnt$Sexe == "F"), 
           mapping = aes(y = - ..count.. ),
           position = "identity") +
  scale_y_continuous(labels = abs) +
  coord_flip()

# Passage aux requ�tes  SQL  

table1=sqldf(' SELECT    Sexe,Age,count(Age) as Nombre from Base_Emprnt1 group by Age')
table1$Intervalles<- cut(table1$Age,seq(0,100,10))
table2= subset(table1, select = c(Age,Intervalles,Sexe,Nombre))
table3=sqldf(' SELECT Sexe,Intervalles, Nombre   from table1 group by  Intervalles ')

table4=sqldf(' SELECT  *  from Base_Emprnt1  order by Sexe ASC')

sqldf('Select * from table4')
sqldf('select min(Age) from table4 where Sexe=="F"')
sqldf('select max(Age) from table4 where Sexe=="F"')
sqldf(' SELECT    Sexe,Age,count(Age) as Nombre from Base_Emprnt1 group by Age')


max(table1$Nombre)
sum(table1$Nombre)

gg <-  ggplot(Base_Emprnt1) +
  aes(x=cut.age,fill=Sexe) +
  geom_bar(data = subset(Base_Emprnt1,Sexe=="F"),aes(y=..count..*(-1))) + # les valeurs deviennent n�gatives
  geom_bar(data = subset(Base_Emprnt1,Sexe=="H")) +
  scale_fill_manual(values = c("pink","blue")) + # Un peu de couleur
  scale_y_discrete(limits=c(-5000,0,5000,30000),labels=c(-5000,0,5000,30000)) + # �tiquettes pour l'axe des x, � modifier selon vos donn�es.
  coord_flip()
plot(gg)

##########################ANALYSE VARIABLES QUANTITATIVES###############
#################AGE##############################################

#BOITE A MOUSTAGE ET PYRAMIDE D AGE
summary(Base_Emprnt.quant)

summary(Base_Emprnt.quant$Age)

Base_Emprnt$cut.age <- cut(Base_Emprnt$Age,seq(0,100,10))

gg <-  ggplot(Base_Emprnt) +
  aes(x=cut.age,fill=Sexe) +
  geom_bar(data = subset(Base_Emprnt,Sexe=="F"),aes(y=..count..*(-1))) + # les valeurs deviennent n�gatives
  geom_bar(data = subset(Base_Emprnt,Sexe=="H")) +
  scale_fill_manual(values = c("pink","blue")) + # Un peu de couleur
  
  plot(gg)

table_age=sqldf(' SELECT Age, count(Age) as  Numb, cut.age as Intervalles from Base_Emprnt group by Age' )

Base_Emprnt$cut.age <- cut(Base_Emprnt$Age,seq(0,100,10),include.lowest = TRUE)

ncol(Base_Emprnt)
Base_Emprnt$Age2=Base_Emprnt$cut.age
table_interv=sqldf('Select  Age2, count(Age2) as Count from Base_Emprnt group by Age2')
write.csv(table_interv,file = "Intervalles_age.csv")

b=boxplot(Base_Emprnt$Age,horizontal=TRUE,col="brown",main="R�partition des �ges",ylim=c(0,100))+ 
  
  table=sqldf('Select Age2,Sexe from Base_Emprnt')
write.csv(table, file = "Pyramide Age.csv")

tabl=sqldf('Select Age2,Sexe from Base_Emprnt group by Age2')

gg <-  ggplot() +
  aes(x=cut.age,fill=sexe) +
  geom_bar(data = subset(cas,sexe=="F"),aes(y=..count..*(-1))) + # les valeurs deviennent n�gatives
  geom_bar(data = subset(cas,sexe=="H")) +
  scale_fill_manual(values = c("pink","blue")) + # Un peu de couleur
  scale_y_discrete(limits=c(-100,0,100,200),labels=c(100,0,100,200)) + # �tiquettes pour l'axe des x, � modifier selon vos donn�es.
  coord_flip()
plot(gg)

geom_boxplot(outlier.colour="black", outlier.shape=16,
             outlier.size=2, notch=FALSE)

library(ggplot2)
# Box plot basique
bb=boxplot( Base_Emprnt$Age, col = grey(0.8),
            main = paste(" Boxplot de l'�ge des individus"),
            ylab = " Age", las = 1,ylim=c(0,100))
rug(Base_Emprnt$Age, side = 2)
abline( h = median(Base_Emprnt$Age, na.rm = TRUE), col = "navy")
text(1.35, 70, "M�diane", col = "navy")
Q1 <- quantile(Base_Emprnt$Age, probs = 0.25, na.rm = TRUE)
abline( h = Q1, col = "darkred")
text(1.25, 62, "Q1 : premier quartile", col = "darkred")
Q3 <- quantile(Base_Emprnt$Age, probs = 0.75, na.rm = TRUE)
abline( h = Q3, col = "darkred")
text(1.25, 83, "Q3 : troisi�me quartile", col = "darkred")
arrows(x0 = 0.7, y0 =quantile(Base_Emprnt$Age, probs = 0.75, na.rm = TRUE), x1 = 0.7,
       y1 = quantile(Base_Emprnt$Age, probs = 0.25, na.rm = TRUE), length = 0.1, code = 3)
text(0.7, 69, "h", pos = 2)
mtext("L'�cart inter-quartile h contient 50 % des individus", side = 1)
abline( h = Q1-1.5*(Q3-Q1), col = "darkgreen")
text(1.35, 42, "Q1 -1.5 h", col = "darkgreen")
abline( h = Q3+1.5*(Q3-Q1), col = "darkgreen")
text(1.35, 104, "Q3 +1.5 h", col = "darkgreen")

bb

boxplot( Base_Emprnt$Age~Base_Emprnt$Sex, col = c("lightpink","lightblue"),
         main = paste("Box plot de l'�ge des individus selon le Sexe "),
         ylab = "Age", las = 1, notch = TRUE)


pyramide=read.csv(file.choose(),sep=";")

ggplot(pyramide)

pyramidGH <- ggplot(pyramide, aes(x = Intervalles, y = Total, fill = Sexe)) + 
  geom_bar(data = subset(pyramide, Sexe == "H"), stat = "identity") + 
  geom_bar(data = subset(pyramide, Sexe == "F"), stat = "identity") + 
  scale_y_discrete(limits=c(-1000,0,1000,20000),labels=c(1000,0,1000,2000))+
  coord_flip() 

pyramidGH



s=summary(Base_Emprnt.quant)

write.csv(s,file="s.csv")
####################"ANALYSE VARIABLES QUANTITATIVES##############"

Base_Emprnt1 <- select(filter(Base_Emprnt, Age.Subscription> 17),names(Base_Emprnt))

summary(Base_Emprnt1) # tableau pour les variables quantitatives 

#  S�paration des  variables quantitaives et qualitatives

ind.quant1 <- sapply(Base_Emprnt1, function(x) is.numeric(x) | is.integer(x))
ind.qual1 <- sapply(Base_Emprnt1, function(x) is.factor(x))

# variables quantitatives
Base_Emprnt.quant1 <- Base_Emprnt1[ ,ind.quant]


# variables qualitatives
Base_Emprnt.qual1<- Base_Emprnt1[ ,ind.qual]

cor_pearson=cor(Base_Emprnt.quant1, method = c("pearson"))

write.csv(cor_pearson,file="Cor_Pearson.csv")

cor(Base_Emprnt.quant1, method = c("kendall"))
cor_spearman=cor(Base_Emprnt.quant1, method = c("spearman"))
write.csv(cor_spearman,file="Cor_Spearman.csv")

#6478

#  gestion des Na dans les colonnes primes 
Claims$Primes.2011[is.na(Claims$Primes.2011)] <- 0
Claims$Primes.2012[is.na(Claims$Primes.2012)] <- 0
Claims$Primes.2013[is.na(Claims$Primes.2013)] <- 0
Claims$Primes.2014[is.na(Claims$Primes.2014)] <- 0
Claims$Primes.2015[is.na(Claims$Primes.2015)] <- 0
Claims$TOTAL_INSURED_AMOUNT[is.na(Claims$TOTAL_INSURED_AMOUNT)] <- 0
Claims$PAID_CLAIMS_IN_LOCAL_CURRENCY[is.na(Claims$PAID_CLAIMS_IN_LOCAL_CURRENCY)] <- 0
Claims$RBNS_AMOUNT_IN_LOCAL_CURRENCY[is.na(Claims$RBNS_AMOUNT_IN_LOCAL_CURRENCY)] <- 0
Claims$Total_Premium[is.na(Claims$Total_Premium)] <- 0
Claims$THEORICAL_DURATION[is.na(Claims$THEORICAL_DURATION)] <- 0
Claims$REAL_DURATION[is.na(Claims$REAL_DURATION)] <- 0
Claims$Death...1.0.[is.na(Claims$Death...1.0.)] <- 0
Claims$OUTSTANDING_SUM_INSURED[is.na(Claims$OUTSTANDING_SUM_INSURED)] <- 0


#6478
Claims1 <- select(filter(Claims,STATUS_AT_THE_CLOSING_DATE=="Death"),names(Claims))

summary(Claims)
sc= summary(Claims1)



        

ind.quant <- sapply(Claims1, function(x) is.numeric(x) | is.integer(x))
ind.qual <- sapply(Claims1, function(x) is.factor(x))
################################ANALYSE BIVARIEE############################
# variables quantitatives
Claims.quant <- Claims1[ ,ind.quant]

Claims.qual <- Claims1[ ,ind.qual]

sc=(Claims.quant)

write.csv(sc,file="sc.csv")
summary(Claims$REAL_DURATION)

#Pearson
#Spearman
corr_claim_quanti=cor(Claims.quant[,-c(6)], method="pearson")

write.csv(corr_claim_quanti,file="Corr_claim.csv")



plot.new()

corrplot(corr_claim_quanti)

col<- colorRampPalette(c("blue", "white", "red"))(20)
heatmap(x = corr_claim_quanti, col = col, symm = TRUE)


corrplot(corr_claim_quanti, type="upper", order="hclust", tl.col="black", tl.srt=45)

cpairs(Base_Emprnt.quant1, gap = .5)


s=summary(Base_Emprnt.quant1)
write.csv(s,file="analyse_quant.csv")



# variables qualitatives
Claims.qual <- Claims[ ,ind.qual]

s_c=summary(Claims.quant)

write.csv(s_c,file="s_c.csv")

#########################Analyse Qualitative###########
# Tableaux crois�s  et Test Ki-deux
tab <- table(Claims.qual$Sexe,Claims.qual$CSP)
cprop(tab)
chisq.test(tab)
chisq.residuals(tab)

mosaicplot(tab)
mosaicplot(tab, las = 3, shade = TRUE)

xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$Sexe, data = Base_Emprnt1)

xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$CSP, data = Base_Emprnt1)
xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$Age.Subscription, data = Base_Emprnt1)

xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$Localisation, data = Base_Emprnt1)
xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$REAL_DURATION, data = Base_Emprnt1)
xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$INITIAL_SUM_INSURED, data = Base_Emprnt1)
summary(Base_Emprnt1$THEORICAL_DURATION)

summary(Base_Emprnt1$REAL_DURATION)


#Discr�tisation

summary(Base_Emprnt1$Age.Subscription)

c(min=min(Base_Emprnt1$Age.Subscription),mean=mean(Base_Emprnt1$Age.Subscription),max=max(Base_Emprnt1$Age.Subscription))


a=trunc( (max(Base_Emprnt1$Age.Subscription)-min(Base_Emprnt1$Age.Subscription) ) /5)

b=0

for(i in (1:4)){
  b[i]= trunc(min(Base_Emprnt1) + i*a)
}



str(Base_Emprnt1$Age.Subscription)
summary(Base_Emprnt1$Age.Subscription)

Breaksage=c(18,25,45,65,81)

Age.Subscription.d=cut(Base_Emprnt1$Age.Subscription,breaks=Breaksage,include.lowest = TRUE)



table(Age.Subscription.d)

dec_age=xtabs(~Base_Emprnt1$Death...1.0. + Age.Subscription.d, data = Base_Emprnt1)

write.csv(dec_age,file="dec_age.csv")

summary(Base_Emprnt1$INITIAL_SUM_INSURED)

Breaksage=c(2000,10000,22000,58500,2013429 )

INITIAL_SUM_INSURED.d=cut(Base_Emprnt1$INITIAL_SUM_INSURED,breaks=Breaksage,include.lowest = TRUE)
table(INITIAL_SUM_INSURED.d)
dec_IS=xtabs(~Base_Emprnt1$Death...1.0. + INITIAL_SUM_INSURED.d, data = Base_Emprnt1)


summary(Base_Emprnt1$THEORICAL_DURATION)

Breaksage=c(4,48,72,84,200 )

Base_Emprnt1$THEORICAL_DURATION.d=cut(Base_Emprnt1$THEORICAL_DURATION,breaks=Breaksage,include.lowest = TRUE)
table(Base_Emprnt1$THEORICAL_DURATION.d)
dec_Theo=xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$THEORICAL_DURATION.d, data = Base_Emprnt1)

Base_Emprnt1 <- select(filter(Base_Emprnt1,Base_Emprnt1$REAL_DURATION != "#NOMBRE!"),names(Base_Emprnt1))
summary(Base_Emprnt1 $REAL_DURATION)


Base_Emprnt1$REAL_DURATION[is.na(Base_Emprnt1$REAL_DURATION)] <- 0
Breaksage=c(2,12,26,47,91 )

Base_Emprnt1$REAL_DURATION.d=cut(Base_Emprnt1$REAL_DURATION,breaks=Breaksage,include.lowest = TRUE)
table(Base_Emprnt1$REAL_DURATION.d)
dec_RD=xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$REAL_DURATION.d, data = Base_Emprnt1)

summary(Base_Emprnt1$Prime.Totale)

Breaksage=c(0,60,250,900,94175 )

Base_Emprnt1$Prime_Totale.d=cut(Base_Emprnt1$Prime.Totale,breaks=Breaksage,include.lowest = TRUE)

table(Base_Emprnt1$Prime_Totale.d)

dec_PT=xtabs(~Base_Emprnt1$Death...1.0. + Base_Emprnt1$Prime_Totale.d, data = Base_Emprnt1)


nrow(Base_Emprnt1)
length(Age.Subscription.d)

Base=Base_Emprnt1
Base=cbind(Base,Age.Subscription.d)
Base=cbind(Base,INITIAL_SUM_INSURED.d)
Base$REAL_DURATION[is.na(Base$REAL_DURATION)] <- 0
Base$INITIAL_SUM_INSURED[is.na(Base$INITIAL_SUM_INSURED)] <- 0
Base$INITIAL_SUM_INSURED.d[is.na(Base$INITIAL_SUM_INSURED.d)] <- 0

class(Base$INITIAL_SUM_INSURED.d)

Base$INITIAL_SUM_INSURED.d=as.numeric(Base$INITIAL_SUM_INSURED.d)
set.seed(111)

d = sort(sample(nrow(Base), nrow(Base) * 0.65))

# Echantillon d'apprentissage
appren <- Base[d, ]
# Echantillon de test
test <- Base[-d, ]
nrow(appren)
nrow(test)
nrow(Base)
nrow(Base)==nrow(test)+nrow(appren)

summary(appren)
summary(test)
attach(appren)
str(appren)
str(test)

# mod�le trivial r�duit � la constante
str_constant <- "~ 1"
# mod�le complet incluant toutes les explicatives potentielles
str_all <- "~Sexe+CSP+Localisation+Age.Subscription.d+INITIAL_SUM_INSURED.d+REAL_DURATION.d+THEORICAL_DURATION.d"

colnames(Base)


require(MASS)

modele <- glm(Death...1.0. ~ 1, data = appren, family = binomial)


modele.forward <- step(modele, scope = list(lower = str_constant, upper = str_all), 
                       trace = TRUE, data = appren, direction = "forward")

summary(modele)

summary(modele.forward)

modele <- glm(Death...1.0. ~ 1, data = appren, family = binomial)
modele.stepwise <- stepAIC(modele, scope = list(lower = str_constant, upper = str_all), 
                           trace = TRUE, data = appren, direction = "both")
summary(modele.stepwise)


logit = function(formula, lien = "logit", data = NULL) {
  glm(formula, family = binomial(link = lien), data)
}

m.logit <- logit(Death...1.0. ~ Sexe+CSP+Localisation+Age.Subscription.d+INITIAL_SUM_INSURED.d+REAL_DURATION.d+THEORICAL_DURATION.d, data = appren)
# r�sultats du mod�le logit
summary(m.logit)
exp(cbind(OR = coef(m.logit), confint(m.logit)))
m.logit
coef(m.logit)

coeffs_logit=cbind(coef(m.logit))
write.csv(coeffs_logit,File="coeffs_logit.csv")

OR=exp(cbind(OR = coef(m.logit)))

write.csv(OR) # ODDS RATIO


summary_logit=summary(m.logit)

table(summary_logit)

cof=summary_logit$coefficients

attributes(m.logit)


# La suite

#(  L'application Excel  automatis� pour calculer les scores selon les modalit�s)

