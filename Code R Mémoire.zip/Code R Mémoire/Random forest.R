#######  FORETS ALEATOIRES #######

## Contruction des forets
setwd("C:/Users/x168165/Desktop/B_D")
#REG LINEAIRE MULTIPLE
install.packages("ggcorrplot")

library(trees)
install.packages("XML")
install.packages("reshape2")
install.packages("plyr")
install.packages("ggplot2")
library(microbenchmark)

library(FSelectorRcpp)
library(installr)
library(RWeka)
library(Amelia)
library(scales)

library(XML)
library(reshape2)
library(plyr)
library(ggplot2)
source('http://klein.uk/R/Viz/pyramids.R')
require(RODBC)
library(sqldf)
install.packages("devtools")
devtools::install_github("ramnathv/rCharts")
library(rCharts)

install.packages("dplyr")
library(dplyr)
library(ggplot2)

install.packages('rattle')
install.packages('rpart.plot')
install.packages('RColorBrewer')
library(rattle)
library(rpart.plot)
library(RColorBrewer)


Base_Emprnt_T= read.csv(file.choose(),sep=";")

nrow(Base_Emprnt_T)

head(Base_Emprnt_T)

str(Base_Emprnt_T)

names(Base_Emprnt_T)
summary(Base_Emprnt_T)
#rajouter comment d�tecter les Na
#  gestion des Na dans les colonnes primes 
Base_Emprnt_T$Primes.2011[is.na(Base_Emprnt_T$Primes.2011)] <- 0
Base_Emprnt_T$Primes.2012[is.na(Base_Emprnt_T$Primes.2012)] <- 0
Base_Emprnt_T$Primes.2013[is.na(Base_Emprnt_T$Primes.2013)] <- 0
Base_Emprnt_T$Primes.2014[is.na(Base_Emprnt_T$Primes.2014)] <- 0
Base_Emprnt_T$Primes.2015[is.na(Base_Emprnt_T$Primes.2015)] <- 0
Base_Emprnt_T$THEORICAL_DURATION[is.na(Base_Emprnt_T$THEORICAL_DURATION)] <- 0
#Recodage des variables: Pour faire une analyse des variables quantitatives et qualitatives

Base_Emprnt_T$INSURED_BIRTHDATE<-as.Date(Base_Emprnt_T$INSURED_BIRTHDATE,format="%d/%m/%Y")             #Chgt de format pour les dates
Base_Emprnt_T$CONTRACT_EFECTIVE_DATE<-as.Date(Base_Emprnt_T$CONTRACT_EFECTIVE_DATE,format="%d/%m/%Y")   #Chgt de format pour les dates

Base_Emprnt_T$THEORETICAL_ENDING_DATE<-as.Date(Base_Emprnt_T$THEORETICAL_ENDING_DATE,format="%d/%m/%Y")

Base_Emprnt_T$STATUS_CHANGE_DATE=as.character(Base_Emprnt_T$STATUS_CHANGE_DATE)
Base_Emprnt_T$STATUS_CHANGE_DATE=as.Date(Base_Emprnt_T$STATUS_CHANGE_DATE)


#Cr�ation d'une variable Prime totale

Base_Emprnt_T$Prime.Totale= Base_Emprnt_T$Primes.2011+Base_Emprnt_T$Primes.2012+Base_Emprnt_T$Primes.2013+Base_Emprnt_T$Primes.2014+Base_Emprnt_T$Primes.2015

#  S�paration des  variables quantitaives et qualitatives

ind.quant <- sapply(Base_Emprnt_T, function(x) is.numeric(x) | is.integer(x))

ind.qual <- sapply(Base_Emprnt_T, function(x) is.factor(x))

# variables quantitatives
Base_Emprnt_T.quant <- Base_Emprnt_T[ ,ind.quant]

Base_Emprnt_T.qual <- Base_Emprnt_T[ ,ind.qual]




summary(Base_Emprnt_T.qual)

summary(Base_Emprnt_T.quant)



summary(Base_Emprnt_T$Age.Subscription)

c(min=min(Base_Emprnt_T$Age.Subscription),mean=mean(Base_Emprnt_T$Age.Subscription),max=max(Base_Emprnt_T$Age.Subscription))


a=trunc( (max(Base_Emprnt_T$Age.Subscription)-min(Base_Emprnt_T$Age.Subscription) ) /5)

b=0

for(i in (1:4)){
  b[i]= trunc(min(Base_Emprnt_T) + i*a)
}



str(Base_Emprnt_T$Age.Subscription)
summary(Base_Emprnt_T$Age.Subscription)

Breaksage=c(18,40,48,53,73)
Age.Subscription.d=cut(Base_Emprnt_T$Age.Subscription,breaks=Breaksage,include.lowest = TRUE)

table(Age.Subscription.d)

dec_age=xtabs(~Base_Emprnt_T$Death_Quali + Age.Subscription.d, data = Base_Emprnt_T)

write.csv(dec_age,file="dec_age.csv")

summary(Base_Emprnt_T$INITIAL_SUM_INSURED)

Breaksage=c(2000,10000,22000,58500,2013429 )

INITIAL_SUM_INSURED.d=cut(Base_Emprnt_T$INITIAL_SUM_INSURED,breaks=Breaksage,include.lowest = TRUE)
table(INITIAL_SUM_INSURED.d)
dec_IS=xtabs(~Base_Emprnt_T$Death_Quali + INITIAL_SUM_INSURED.d, data = Base_Emprnt_T)

summary(Base_Emprnt_T$THEORICAL_DURATION)

Breaksage=c(4,48,72,84,200 )
Base_Emprnt_T$THEORICAL_DURATION.d=cut(Base_Emprnt_T$THEORICAL_DURATION,breaks=Breaksage,include.lowest = TRUE)
table(Base_Emprnt_T$THEORICAL_DURATION.d)
dec_Theo=xtabs(~Base_Emprnt_T$Death_Quali  + Base_Emprnt_T$THEORICAL_DURATION.d, data = Base_Emprnt_T)


Base_Emprnt_T=cbind(Base_Emprnt_T,Age.Subscription.d,INITIAL_SUM_INSURED.d)

cor1=cor(Base_Emprnt_T$THEORICAL_DURATION,Base_Emprnt_T$Age.Subscription,method = c("spearman"))
cor2=cor(Base_Emprnt_T$THEORICAL_DURATION,Base_Emprnt_T$Age.Subscription,method = c("pearson"))

res_cor=matrix(c("spearman","pearson",cor1,cor2),nrow=2,ncol=2,byrow=T)


cor3=cor(Base_Emprnt_T$INITIAL_SUM_INSURED,Base_Emprnt_T$Age.Subscription,method = c("spearman"))
cor4=cor(Base_Emprnt_T$INITIAL_SUM_INSURED,Base_Emprnt_T$Age.Subscription,method = c("pearson"))

res_cor2=matrix(c("spearman","pearson",cor3,cor4),nrow=2,ncol=2,byrow=T)

tab=table(Base_Emprnt_T.qual$Sexe,Base_Emprnt_T.qual$CSP)

lprop(tab)
cprop(tab)

chisq.test(tab)

chisq.residuals(tab)
mosaicoplot(tab)

plot(Base_Emprnt_T.qual$CSP,Base_Emprnt_T.qual$Sexe)

nb_lignes=floor(nrow(Base_Emprnt_T)*0.75)

Base_Emprnt_T=Base_Emprnt_T[sample(nrow(Base_Emprnt_T)),]
Base.train=Base_Emprnt_T[1:nb_lignes,]
Base.test=Base_Emprnt_T[(nb_lignes+1):nrow(Base_Emprnt_T),]


lapply(Base.train,class)
summary(Base.train$Death_Quali)
summary(Base.test$Death_Quali)


#Validation de la r�partition Train et Test environ 98% No

class(Base.test$Death_Quali)

prop.table(table(Base.train$Death_Quali))

prop.table(table(Base.test$Death_Quali))

t1.rf<-proc.time()


str(Base.train)
# Un random Forest  avec 500  et 1000 arbres  pour voir si l'erreur diminue

# Nous avons r�duit les cat�gories de la variable localisation � 53 villes en mettant les 30 villes avec une souscription t�rs faible dans 

rf <- randomForest(x=Base.train[,-c(1,12,11,10,9,8)],y=Base.train[,1],xtest=Base.train 
                   [,-c(1,12,11,10,9,8)],ytest=Base.train[ ,1], do.trace=5, ntree=500,mtry=3) 

summary(rf)

par(mar = rep(2, 1))

plot(rf)


#Importance des variables

importanceOrder=order(-rf$importance)

names=rownames(rf$importance)[importanceOrder][1:7]

varImpPlot(rf,type=2,col="blue",main="Importance des variables")


# matrice de confusion  OOB 

print(mc<-rf$confusion)

#taux d'erreur OOB

print((mc[2,1]+mc[1,2])/sum(mc[1:2,1:2]))

# Optimisation de la for�t des arbres 

# Tuning parametre "mtry"

mtry <- tuneRF(Base.train[,-c(1,12,11,10,9,8)],Base.train[,1],ntreeTry=200,stepFactor=1,improve=0.05,trace=TRUE, plot=TRUE, doBest=FALSE)

mtry

mtry.opt <- mtry[,"mtry"][which.min(mtry[,"OOBError"])]

mtry.opt



