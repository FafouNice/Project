setwd("C:/Users/x168165/Desktop/B_D")
#REG LINEAIRE MULTIPLE
install.packages("ggcorrplot")

library(trees)
install.packages("XML")
install.packages("reshape2")
install.packages("plyr")
install.packages("ggplot2")
library(microbenchmark)

library(FSelectorRcpp)
library(installr)
library(RWeka)
library(Amelia)
library(scales)

library(XML)
library(reshape2)
library(plyr)
library(ggplot2)
source('http://klein.uk/R/Viz/pyramids.R')
require(RODBC)
library(sqldf)
install.packages("devtools")
devtools::install_github("ramnathv/rCharts")
library(rCharts)

install.packages("dplyr")
library(dplyr)
library(ggplot2)

install.packages('rattle')
install.packages('rpart.plot')
install.packages('RColorBrewer')
library(rattle)
library(rpart.plot)
library(RColorBrewer)
library(randomForest)

Base_Emprnt_T= read.csv(file.choose(),sep=";")

nrow(Base_Emprnt_T)
head(Base_Emprnt_T)
str(Base_Emprnt_T)
names(Base_Emprnt_T)
summary(Base_Emprnt_T)
#rajouter comment d�tecter les Na
#  gestion des Na dans les colonnes primes 
Base_Emprnt_T$Primes.2011[is.na(Base_Emprnt_T$Primes.2011)] <- 0
Base_Emprnt_T$Primes.2012[is.na(Base_Emprnt_T$Primes.2012)] <- 0
Base_Emprnt_T$Primes.2013[is.na(Base_Emprnt_T$Primes.2013)] <- 0
Base_Emprnt_T$Primes.2014[is.na(Base_Emprnt_T$Primes.2014)] <- 0
Base_Emprnt_T$Primes.2015[is.na(Base_Emprnt_T$Primes.2015)] <- 0

#Recodage des variables: Pour faire une analyse des variables quantitatives et qualitatives

Base_Emprnt_T$INSURED_BIRTHDATE<-as.Date(Base_Emprnt_T$INSURED_BIRTHDATE,format="%d/%m/%Y")             #Chgt de format pour les dates
Base_Emprnt_T$CONTRACT_EFECTIVE_DATE<-as.Date(Base_Emprnt_T$CONTRACT_EFECTIVE_DATE,format="%d/%m/%Y")   #Chgt de format pour les dates

Base_Emprnt_T$THEORETICAL_ENDING_DATE<-as.Date(Base_Emprnt_T$THEORETICAL_ENDING_DATE,format="%d/%m/%Y")

Base_Emprnt_T$STATUS_CHANGE_DATE=as.character(Base_Emprnt_T$STATUS_CHANGE_DATE)
Base_Emprnt_T$STATUS_CHANGE_DATE=as.Date(Base_Emprnt_T$STATUS_CHANGE_DATE)


#Cr�ation d'une variable Prime totale

Base_Emprnt_T$Prime.Totale= Base_Emprnt_T$Primes.2011+Base_Emprnt_T$Primes.2012+Base_Emprnt_T$Primes.2013+Base_Emprnt_T$Primes.2014+Base_Emprnt_T$Primes.2015

#  S�paration des  variables quantitaives et qualitatives

ind.quant <- sapply(Base_Emprnt_T, function(x) is.numeric(x) | is.integer(x))

ind.qual <- sapply(Base_Emprnt_T, function(x) is.factor(x))

# variables quantitatives
Base_Emprnt_T.quant <- Base_Emprnt_T[ ,ind.quant]

Base_Emprnt_T.qual <- Base_Emprnt_T[ ,ind.qual]




summary(Base_Emprnt_T.qual)

summary(Base_Emprnt_T.quant)



summary(Base_Emprnt_T$Age.Subscription)

c(min=min(Base_Emprnt_T$Age.Subscription),mean=mean(Base_Emprnt_T$Age.Subscription),max=max(Base_Emprnt_T$Age.Subscription))


a=trunc( (max(Base_Emprnt_T$Age.Subscription)-min(Base_Emprnt_T$Age.Subscription) ) /5)

b=0

for(i in (1:4)){
  b[i]= trunc(min(Base_Emprnt_T) + i*a)
}



str(Base_Emprnt_T$Age.Subscription)
summary(Base_Emprnt_T$Age.Subscription)

Breaksage=c(18,40,48,53,73)
Age.Subscription.d=cut(Base_Emprnt_T$Age.Subscription,breaks=Breaksage,include.lowest = TRUE)

table(Age.Subscription.d)

dec_age=xtabs(~Base_Emprnt_T$Death_Quali + Age.Subscription.d, data = Base_Emprnt_T)

write.csv(dec_age,file="dec_age.csv")

summary(Base_Emprnt_T$INITIAL_SUM_INSURED)

Breaksage=c(2000,10000,22000,58500,2013429 )

INITIAL_SUM_INSURED.d=cut(Base_Emprnt_T$INITIAL_SUM_INSURED,breaks=Breaksage,include.lowest = TRUE)
table(INITIAL_SUM_INSURED.d)
dec_IS=xtabs(~Base_Emprnt_T$Death_Quali + INITIAL_SUM_INSURED.d, data = Base_Emprnt_T)

summary(Base_Emprnt_T$THEORICAL_DURATION)

Breaksage=c(4,48,72,84,200 )
Base_Emprnt_T$THEORICAL_DURATION.d=cut(Base_Emprnt_T$THEORICAL_DURATION,breaks=Breaksage,include.lowest = TRUE)
table(Base_Emprnt_T$THEORICAL_DURATION.d)
dec_Theo=xtabs(~Base_Emprnt_T$Death_Quali  + Base_Emprnt_T$THEORICAL_DURATION.d, data = Base_Emprnt_T)


Base_Emprnt_T=cbind(Base_Emprnt_T,Age.Subscription.d,INITIAL_SUM_INSURED.d)

cor1=cor(Base_Emprnt_T$THEORICAL_DURATION,Base_Emprnt_T$Age.Subscription,method = c("spearman"))
cor2=cor(Base_Emprnt_T$THEORICAL_DURATION,Base_Emprnt_T$Age.Subscription,method = c("pearson"))

res_cor=matrix(c("spearman","pearson",cor1,cor2),nrow=2,ncol=2,byrow=T)


cor3=cor(Base_Emprnt_T$INITIAL_SUM_INSURED,Base_Emprnt_T$Age.Subscription,method = c("spearman"))
cor4=cor(Base_Emprnt_T$INITIAL_SUM_INSURED,Base_Emprnt_T$Age.Subscription,method = c("pearson"))

res_cor2=matrix(c("spearman","pearson",cor3,cor4),nrow=2,ncol=2,byrow=T)

tab=table(Base_Emprnt_T.qual$Sexe,Base_Emprnt_T.qual$CSP)

lprop(tab)
cprop(tab)

chisq.test(tab)

chisq.residuals(tab)
mosaicoplot(tab)

plot(Base_Emprnt_T.qual$CSP,Base_Emprnt_T.qual$Sexe)

nb_lignes=floor(nrow(Base_Emprnt_T)*0.75)

Base_Emprnt_T=Base_Emprnt_T[sample(nrow(Base_Emprnt_T)),]
Base.train=Base_Emprnt_T[1:nb_lignes,]
Base.test=Base_Emprnt_T[(nb_lignes+1):nrow(Base_Emprnt_T),]


lapply(Base.train,class)
summary(Base.train$Death_Quali)
summary(Base.test$Death_Quali)


#Validation de la r�partition Train et Test environ 98% No

class(Base.test$Death_Quali)

prop.table(table(Base.train$Death_Quali))

prop.table(table(Base.test$Death_Quali))


Base.Tree=rpart(Death_Quali~.,data=Base.train,method="class", 
                control = rpart.control(cp=0))


summary((Base.Tree))

names(Base.Tree)

plotcp(Base.Tree); 

printcp(Base.Tree)

prp(Base.Tree, uniform = TRUE, extra = 0, type = 2, branch = 0, cex = 0.7, Margin = 0, compress = TRUE)

## SIMPLIFICATION DE L'ARBRE
# Recuperation du cp minimisant  l'erreur


cp_min=Base.Tree$cptable[which.min(Base.Tree$cptable[,4]),1]

Base.Tree_Opt= prune(Base.Tree, cp = Base.Tree$cptable[which.min(Base.Tree$cptable[,4]),1]) 

# Representation de l'arbre obtenu
par(mfrow = c(1, 1), mar = c(1, 1, 1, 1))
plot(Base.Tree_Opt, uniform = T, compress = T, margin = 0.1, branch = 0.3)
text(Base.Tree_Opt, use.n = T, digits = 3, cex = 0.6)
prp(Base.Tree_Opt, uniform = TRUE, extra=1,type=1, branch = 0, cex = 0.7, Margin = 0, compress=TRUE)
fancyRpartPlot(Base.Tree_Opt)
# Arbre illisible, ajout d'une contraite sur le nb d'ind min par feuille avec minbucket

## ARBRE COMPLET  


# Complexite

plot(Base.Tree$cptable[,2], Base.Tree$cptable[,4],xlab='Complexite',ylab='CV erreur',main='Evo du CP')

print(Base.Tree_Opt)




Base.test_Predict=predict(Base.Tree_Opt,newdata=Base.test,type="class")

nrow(Base.test_Predict)
nrow(Base.test)
summary(Base.test_Predict)

summary(Base.test$Death_Quali)

mc=table(Base.test$Death_Quali,Base.test_Predict)
table(Base.test$Death_Quali)

erreur.classement=1.0-(mc[1,1]+mc[2,2])/sum(mc)

prediction=mc[2,2]/sum(mc[2,])

print(prediction)



####### II.2. FORETS ALEATOIRES #######
t1.rf<-proc.time()

## Contruction des forets

freq.rf <- randomForest(fm2, data = donnees_freq_app_echantillon, ntree=200, mtry=3)
summary(freq.rf)
freq.rf
#Call:
#  randomForest(formula = fm2, data = donnees_freq_app_echantillon,      ntree = 200, mtry = 3) 
#Type of random forest: regression
#Number of trees: 200
#No. of variables tried at each split: 3
#Mean of squared residuals: 0.05822304
#% Var explained: -2.17

min(freq.rf$mse)
# 0.05822304 <=> nbr = 200 arbres


plot(freq.rf)
# l'erreur se stabilise a partir de 100 arbres

varImpPlot(freq.rf)
# Variables les plus importantes : Density et DrivAge

hist(treesize(freq.rf))
max(treesize(freq.rf))
# noeuds max = 5169

# Tuning parametre "mtry"
mtry <- tuneRF(donnees_freq_app_echantillon[,-1],donnees_freq_app_echantillon[,1],ntreeTry=200,stepFactor=1,improve=0.05,trace=TRUE, plot=TRUE, doBest=FALSE)
mtry
mtry.opt <- mtry[,"mtry"][which.min(mtry[,"OOBError"])]
mtry.opt
# mtry optimal = 3, par methode OOB Error

## Foret optimale
freq.rf.opt <- randomForest(fm2, data = donnees_freq_app_echantillon, ntree=200, mtry=3)

## Prediction
freq.predict.rf <- predict(freq.rf.opt,donnees_freq_valid_echantillon)

t2.rf<-proc.time()-t1.rf

summary(donnees_freq_valid_echantillon$ClaimNb)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000  

summary(freq.predict.rf)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.02032 0.03900 0.05639 0.07025 0.77970    

## Calcul des erreurs
freq.SE.rf <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.rf)^2)
freq.SE.rf
# 1212.96
freq.MSE.rf <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.rf)^2)
freq.MSE.rf
# 0.05641672
freq.RMSE.rf <- sqrt(freq.MSE.rf)
freq.RMSE.rf
# 0.237522

# Frequence moyenne Estimee
freq.mean.rf<-mean(freq.predict.rf)


#Affichage des resultats ensemble
freq.rf.results<-data.frame(freq.SE.rf,freq.MSE.rf,freq.RMSE.rf,FreqMoyenneHistorique,freq.mean.rf)
names(freq.rf.results)[1]<-"SE"
names(freq.rf.results)[2]<-"MSE"
names(freq.rf.results)[3]<-"RMSE"
names(freq.rf.results)[4]<-"Mean frequence"
names(freq.rf.results)[5]<-"Mean frequence estimee"
freq.rf.results
#SE        MSE         RMSE             Mean frequence   Mean frequence estimee
#1212.96 0.05641672  0.237522           0.05181395             0.05638673


