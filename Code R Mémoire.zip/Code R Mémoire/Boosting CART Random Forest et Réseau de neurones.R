
##########################################################################
##########            I - TRAITEMENT DES DONNEES                ##########
##########################################################################

########## Libraries utilisees ##########
set.seed(12345)

#install.packages("rpart.plot")
#install.packages("gbm")
#install.packages("randomForest")
#install.packages("ranger")
#install.packages("mboost")
#install.packages("neuralnet")

library(xts)
library(sp)

library(ggplot2)
library(evir)
library(MASS)
library(pscl)
library(rpart)
library(rpart.plot)
library(stats)
library(splines)
library(randomForest)
library(gbm)
library(nnet)
library(caret)
library(xgboost)
library(ranger)
#library(mboost)
library(neuralnet)

data(freMTPL2freq)
data(freMTPL2sev)

# certaines lignes de code ont ete reprises des projets de tarification effectues au premier semestre pour le tri prealable des variables


####### DONNEES POUR LE MODELE DE FREQUENCE #######

summary(freMTPL2freq) #statistiques de base sur chaque variable
str(freMTPL2freq) #type de variables et modalites

for (i in 1:ncol(freMTPL2freq)){
  print(sum(is.na(freMTPL2freq[,i])))
} # il n'y a pas d'observations NA

## Contruction des donnees pour la frequence des sinistres
donnees_freq <- freMTPL2freq[,-1]

str(donnees_freq)

donnees_freq$ClaimNb = as.numeric(donnees_freq$ClaimNb) #conversion en numeric

## Conversion des variables qualitatives en factor
donnees_freq$Area = as.factor(donnees_freq$Area)
donnees_freq$VehPower = as.factor(donnees_freq$VehPower)
donnees_freq$VehBrand = as.factor(donnees_freq$VehBrand)
donnees_freq$VehGas = as.factor(donnees_freq$VehGas)
donnees_freq$Region = as.factor(donnees_freq$Region)

str(donnees_freq)
summary(donnees_freq)


####### DONNEES POUR LE MODELE COUT ###############

summary(freMTPL2sev) #statistiques de base sur chaque variable
dim(freMTPL2sev)
str(freMTPL2sev)#type de variables et modalites
sum(is.na(freMTPL2sev$IDpol)) # 0
sum(is.na(freMTPL2sev$ClaimAmount)) # 0 : il n'y a pas d'observations NA


## On merge les 2 tables
donnees_cout <- merge(x=freMTPL2freq,y=freMTPL2sev,by="IDpol",all.x=TRUE,all.y=TRUE)
sum(is.na(donnees_cout$ClaimNb)) # il y a 195 montants dont on n'a pas d'informations de profils de risques => on les enleve
donnees_cout <- donnees_cout[!is.na(donnees_cout$ClaimNb),]

## On enleve des observations qui ont 0 ClaimNb
donnees_cout <- donnees_cout[donnees_cout$ClaimNb != 0,]

sum(is.na(donnees_cout$ClaimAmount)) # il y a 9116 policies qui ont des sinistres mais on n'a pas d'informations de montants => on les enleve
donnees_cout <- donnees_cout[!is.na(donnees_cout$ClaimAmount),]

donnees_cout <- donnees_cout[,-c(1,2,3)] # on enleve colonne IDpol, ClaimNb et Exposure

summary(donnees_cout)

## Conversion des variables qualitatives en factor
donnees_cout$Area = as.factor(donnees_cout$Area)
donnees_cout$VehPower = as.factor(donnees_cout$VehPower)
donnees_cout$VehBrand = as.factor(donnees_cout$VehBrand)
donnees_cout$VehGas = as.factor(donnees_cout$VehGas)
donnees_cout$Region = as.factor(donnees_cout$Region)

summary(donnees_cout)
str(donnees_cout)


####### DETECTION DES VALEURS ABERRRANTES #######

## Exposition
summary(donnees_freq$Exposure)
boxplot(x = donnees_freq$Exposure)

# Nombre d'expositions au dessus de 1
length(donnees_freq$Exposure[donnees_freq$Exposure>1])/dim(donnees_freq)[1] # 0.001805275

# On enleve les observations qui ont des exposition > 1
donnees_freq <- donnees_freq[-which(donnees_freq$Exposure>1),]

## Variable VehAge
summary(donnees_freq$VehAge)
summary(donnees_cout$VehAge)
boxplot(donnees_freq$VehAge)

boxplot(donnees_cout$VehAge)

length(donnees_freq$VehAge[donnees_freq$VehAge>40])/dim(donnees_freq)[1] # 0.034% => on enleve
length(donnees_cout$VehAge[donnees_cout$VehAge>40])/dim(donnees_cout)[1] # 0.01% => on enleve

donnees_freq <- donnees_freq[-which(donnees_freq$VehAge>40),]
donnees_cout <- donnees_cout[-which(donnees_cout$VehAge>40),]

## Variable Density
summary(donnees_freq$Density)
boxplot(donnees_freq$Density)

## Variable ClaimAmount
summary(donnees_cout$ClaimAmount)
boxplot(donnees_cout$ClaimAmount) #4 valeurs tres grandes

####### Seperation des sinistres attritionels et graves
plot(donnees_cout$ClaimAmount,type="h")
meplot(donnees_cout$ClaimAmount,type="o")

seuil <- quantile(donnees_cout$ClaimAmount,0.95) # 95% des variables dont le montant de ClaimAmout est superieur a 4765.56 
seuil
donnees_cout_attri <- donnees_cout[-which(donnees_cout$ClaimAmount>seuil),]
donnees_cout_large <- donnees_cout[which(donnees_cout$ClaimAmount>seuil),]
summary(donnees_cout$ClaimAmount)
summary(donnees_cout_attri$ClaimAmount)
summary(donnees_cout_large$ClaimAmount)

####### Determination de la prime pure historique
CoutMoyenHistorique <- mean(donnees_cout_attri$ClaimAmount)
CoutMoyenHistorique # 1142.6
FreqMoyenneHistorique <- mean(donnees_freq$ClaimNb)
FreqMoyenneHistorique # 0.05327547
TarifHistorique <- FreqMoyenneHistorique * CoutMoyenHistorique
# Pour le rapport :
CoutMoyenHistorique # 1142.6
FreqMoyenneHistorique # 0.05327547
TarifHistorique # 60.87255

####### CREATION DES DONNEES D'APPRENTISSAGE ET DE VALIDATION #######

####### Frequence
# les temps de calcul etant beaucoup trop longs avec le nombre initial de donnes, nous decidons de prendre aleatoirement 50 000 donnees pour l'echantillon d'apprentissage et 21 500 pour celui de validation (soit a peu pres 30% de la taille de l'echantillon d'apprentissage
H1 <- sample(1:nrow(donnees_freq),50000,replace=FALSE)
H2 <- seq(1,nrow(donnees_freq))[-H1]
donnees_freq_app_echantillon <- donnees_freq[H1,]
donnees_freq_valid_echantillon <- donnees_freq[H2,]
donnees_freq_valid_echantillon <- donnees_freq_valid_echantillon[sample(1:nrow(donnees_freq_valid_echantillon),21500),]

dim(donnees_freq_app_echantillon) # 50 000
dim(donnees_freq_valid_echantillon) # 21 500

summary(donnees_freq)
summary(donnees_freq_app_echantillon) # meme proportion entre base initiale et base d'apprentissage
summary(donnees_freq_valid_echantillon) # nos bases sont bien representatives de la base de depart

####### Cout
K1 <- sample(1:nrow(donnees_cout_attri),2/3*nrow(donnees_cout_attri),replace=FALSE) #2/3 des donnees
K2 <- seq(1,nrow(donnees_cout_attri))[-K1] # 1/3 des donnees
donnees_cout_attri_app <- donnees_cout_attri[K1,]
donnees_cout_attri_valid <- donnees_cout_attri[K2,]

dim(donnees_cout_attri_app) # 16746    10
dim(donnees_cout_attri_valid) # 8373   10

summary(donnees_cout)
summary(donnees_cout_attri_app) # meme proportion entre base initiale et base d'apprentissage
summary(donnees_cout_attri_valid) # nos bases sont bien representatives de la base de depart


########################################################################################
##########                      II. MODELES DE FREQUENCE                      ##########
########################################################################################

####### II.1. ARBRE CART #######
t1.tree<-proc.time()

## On determine la formule pour des arbres
n1 <- names(donnees_freq)
fm1 <- as.formula(paste("ClaimNb ~ offset(log(Exposure)) +", paste(n1[!n1 %in% "ClaimNb" & !n1 %in% "Exposure"], collapse = " + "))) # ClaimNb est la variable a expliquer
fm1
fm2 <- as.formula(paste("ClaimNb ~ offset(Exposure) +", paste(n1[!n1 %in% "ClaimNb" & !n1 %in% "Exposure"], collapse = " + ")))
fm2

## L'arbre maximal
freq.tree <- rpart(formula=fm1, data=donnees_freq_app_echantillon, method="poisson", 
                   control = rpart.control(minsplit=1,minbucket=1,cp=0,maxcompete=2,xval=5))

#rpart.plot(freq.tree)
freq.tree$cptable
plotcp(freq.tree) #y-axis = error : l'arbre maximal est de surapprentissage, donc il faut l'elaguer : on choisit le cp qui minimise l'erreur

## Arbre elague
freq.bestcp <- freq.tree$cptable[which.min(freq.tree$cptable[,"xerror"]),"CP"]
# dans cptable, colonne "xerror" = 5-fold cross-validated relative error.

freq.tree.pruned <- prune(freq.tree, cp = freq.bestcp)
freq.tree.pruned
rpart.plot(freq.tree.pruned)


## Prediction
freq.predict.tree <- predict(freq.tree.pruned,donnees_freq_valid_echantillon)*donnees_freq_valid_echantillon$Exposure

t2.tree<-proc.time()-t1.tree

summary(donnees_freq_valid_echantillon$ClaimNb)
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000 

summary(freq.predict.tree)
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#0.0001225 0.0171400 0.0448400 0.0523300 0.0780100 0.7697000  

# On trouve que mean(y^) ~ mean (y) donc l'estimation de l'arbre CART est tres bonne

## Calcul des erreurs
freq.SE.tree <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.tree)^2)
freq.SE.tree
# 1184.053
freq.MSE.tree <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.tree)^2)
freq.MSE.tree
# 0.05507224
freq.RMSE.tree <- sqrt(freq.MSE.tree)
freq.RMSE.tree
# 0.2346748

## Frequence moyenne
freq.mean.reel <- mean(donnees_freq_valid_echantillon$ClaimNb)
# 0.05181395
freq.mean.tree <-mean(freq.predict.tree)
# 0.05232583

## Affichage des resultats ensemble
freq.tree.results<-data.frame(freq.SE.tree,freq.MSE.tree,freq.RMSE.tree,FreqMoyenneHistorique,freq.mean.tree)
names(freq.tree.results)[1]<-"SE"
names(freq.tree.results)[2]<-"MSE"
names(freq.tree.results)[3]<-"RMSE"
names(freq.tree.results)[4]<-"Mean frequence"
names(freq.tree.results)[5]<-"Mean frequence estimee"
freq.tree.results
#SE             MSE      RMSE        Mean frequence       Mean frequence estimee
#1184.053 0.05507224 0.2346748     0.05181395             0.05232583


####### II.2. FORETS ALEATOIRES #######
t1.rf<-proc.time()

## Contruction des forets

freq.rf <- randomForest(fm2, data = donnees_freq_app_echantillon, ntree=200, mtry=3)
summary(freq.rf)
freq.rf
#Call:
#  randomForest(formula = fm2, data = donnees_freq_app_echantillon,      ntree = 200, mtry = 3) 
#Type of random forest: regression
#Number of trees: 200
#No. of variables tried at each split: 3
#Mean of squared residuals: 0.05822304
#% Var explained: -2.17

min(freq.rf$mse)
# 0.05822304 <=> nbr = 200 arbres


plot(freq.rf)
# l'erreur se stabilise a partir de 100 arbres

varImpPlot(freq.rf)
# Variables les plus importantes : Density et DrivAge

hist(treesize(freq.rf))
max(treesize(freq.rf))
# noeuds max = 5169

# Tuning parametre "mtry"
mtry <- tuneRF(donnees_freq_app_echantillon[,-1],donnees_freq_app_echantillon[,1],ntreeTry=200,stepFactor=1,improve=0.05,trace=TRUE, plot=TRUE, doBest=FALSE)
mtry
mtry.opt <- mtry[,"mtry"][which.min(mtry[,"OOBError"])]
mtry.opt
# mtry optimal = 3, par methode OOB Error

## Foret optimale
freq.rf.opt <- randomForest(fm2, data = donnees_freq_app_echantillon, ntree=200, mtry=3)

## Prediction
freq.predict.rf <- predict(freq.rf.opt,donnees_freq_valid_echantillon)

t2.rf<-proc.time()-t1.rf

summary(donnees_freq_valid_echantillon$ClaimNb)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000  

summary(freq.predict.rf)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.02032 0.03900 0.05639 0.07025 0.77970    

## Calcul des erreurs
freq.SE.rf <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.rf)^2)
freq.SE.rf
# 1212.96
freq.MSE.rf <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.rf)^2)
freq.MSE.rf
# 0.05641672
freq.RMSE.rf <- sqrt(freq.MSE.rf)
freq.RMSE.rf
# 0.237522

# Frequence moyenne Estimee
freq.mean.rf<-mean(freq.predict.rf)


#Affichage des resultats ensemble
freq.rf.results<-data.frame(freq.SE.rf,freq.MSE.rf,freq.RMSE.rf,FreqMoyenneHistorique,freq.mean.rf)
names(freq.rf.results)[1]<-"SE"
names(freq.rf.results)[2]<-"MSE"
names(freq.rf.results)[3]<-"RMSE"
names(freq.rf.results)[4]<-"Mean frequence"
names(freq.rf.results)[5]<-"Mean frequence estimee"
freq.rf.results
#SE        MSE         RMSE             Mean frequence   Mean frequence estimee
#1212.96 0.05641672  0.237522           0.05181395             0.05638673


####### II.3. GBM ####### 
t1.gbm<-proc.time()
## Training
freq.gbm <- gbm(formula=fm1,
                distribution="poisson", data=donnees_freq_app_echantillon, 
                n.trees=10000,
                shrinkage=0.001,
                train.fraction = 0.75)

## shrinkage = taux d'apprentissage

freq.gbm
summary(freq.gbm)

best.iter <- gbm.perf(freq.gbm,method="OOB")
# 5944 : nombrd d'iterations optimal pour le gbm

## Prediction
freq.predict.gbm <- predict.gbm(freq.gbm,donnees_freq_valid_echantillon,best.iter,type="response")*donnees_freq_valid_echantillon$Exposure

t2.gbm<-proc.time()-t1.gbm

summary(donnees_freq_valid_echantillon$ClaimNb)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000 

summary(freq.predict.gbm)
# Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
#0.000159 0.017800 0.047910 0.051920 0.075530 0.889000 

## Calcul des erreurs
freq.SE.gbm <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.gbm)^2)
freq.SE.gbm
# 1176.014
freq.MSE.gbm <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.gbm)^2)
freq.MSE.gbm
# 0.05469835
freq.RMSE.gbm <- sqrt(freq.MSE.gbm)
freq.RMSE.gbm
# 0.2338768

#frequence moyenne 
freq.mean.gbm<-mean(freq.predict.gbm)
# 0.05191578

#Affichage des resultats ensemble 
freq.gbm.results<-data.frame(freq.SE.gbm,freq.MSE.gbm,freq.RMSE.gbm,FreqMoyenneHistorique,freq.mean.gbm)
names(freq.gbm.results)[1]<-"SE"
names(freq.gbm.results)[2]<-"MSE"
names(freq.gbm.results)[3]<-"RMSE"
names(freq.gbm.results)[4]<-"Mean frequence"
names(freq.gbm.results)[5]<-"Mean frequence estimee"
freq.gbm.results
#SE        MSE      RMSE Mean frequence Mean frequence estimee
# 1176.014 0.05469835 0.2338768     0.05181395             0.05191578

####### II.4. XGBOOST #######
t1.XGboost<-proc.time()

## Preparation
freq.XGboost.train.mf<- model.frame(fm1,donnees_freq_app_echantillon)
freq.XGboost.train.m<- model.matrix(attr(freq.XGboost.train.mf,"terms"),data = donnees_freq_app_echantillon)
freq.XGboost.train <- xgb.DMatrix(freq.XGboost.train.m,label = donnees_freq_app_echantillon$ClaimNb)

freq.XGboost.test.mf<- model.frame(fm1,donnees_freq_valid_echantillon)
freq.XGboost.test.m<- model.matrix(attr(freq.XGboost.test.mf,"terms"),data = donnees_freq_valid_echantillon)
freq.XGboost.test <- xgb.DMatrix(freq.XGboost.test.m,label = donnees_freq_valid_echantillon$ClaimNb)

## Parametres optimaux pour la fonction XGBoost
# params <- list(booster = "gbtree", objective = "count:poisson", eta=0.015,gamma=0, max_depth=10, min_child_weight=0, subsample=.5, colsample_bytree=.5,eval_metric='rmse',nthread=4,verbose=TRUE,seed=123)
# 
# xgbcv <- xgb.cv( params = params, data = freq.XGboost.train, nrounds = 2000, stratified = T, print_every_n = 50, early_stop_rounds = 20, maximize = F,nfold = 5)

param0 <- list(
  "objective"  = "count:poisson"
  , "eval_metric" = "rmse"
  , "eta" = 0.015
  , "subsample" = 0.5
  , "colsample_bytree" = 0.5
  , "min_child_weight" = 0
  , "max_depth" = 10
  , "nthread"=4
)

## Training
freq.XGboost = xgb.train(nrounds=300, params=param0, data=freq.XGboost.train)
freq.XGboost

## Prediction
freq.predict.XGboost<-predict(freq.XGboost,freq.XGboost.test)*donnees_freq_valid_echantillon$Exposure

t2.XGboost<-proc.time()-t1.XGboost

summary(donnees_freq_valid_echantillon$ClaimNb)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000  

summary(freq.predict.XGboost)
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#0.0002114 0.0169600 0.0476200 0.0519100 0.0877600 0.2434000 

## Calcul des erreurs
freq.SE.XGboost <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.XGboost)^2)
freq.SE.XGboost
# 1186.571

freq.MSE.XGboost <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.XGboost)^2)
freq.MSE.XGboost
# 0.05518936

freq.RMSE.XGboost <- sqrt(freq.MSE.XGboost)
freq.RMSE.XGboost
# 0.2349242

# Frequence moyenne 
freq.mean.XGboost<-mean(freq.predict.XGboost)


#Affichage des resultats ensemble
freq.XGboost.results<-data.frame(freq.SE.XGboost,freq.MSE.XGboost,freq.RMSE.XGboost,FreqMoyenneHistorique,freq.mean.XGboost)
names(freq.XGboost.results)[1]<-"SE"
names(freq.XGboost.results)[2]<-"MSE"
names(freq.XGboost.results)[3]<-"RMSE"
names(freq.XGboost.results)[4]<-"Mean frequence"
names(freq.XGboost.results)[5]<-"Mean frequence estimee"
freq.XGboost.results
#SE        MSE      RMSE Mean frequence Mean frequence estimee
#1186.571 0.05518936 0.2349242     0.05181395             0.05191433

####### II.5. RESEAUX DE NEURONES #######
t1.nn<-proc.time()
## Training
cv.nn <- trainControl(method = "cv",number =  5) #cross validation 
grid.nn <- expand.grid(decay = c(0.1,0.01,0.001), size = c(3,4,5,7)) #grille de parametres a tester
freq.nn <- train(fm2,data=donnees_freq_app_echantillon, method='nnet',trControl=cv.nn,tuneGrid=grid.nn,maxit=5000)

## Prediction
freq.predict.nn <- predict(freq.nn,newdata=donnees_freq_valid_echantillon,type="raw")
t2.nn<-proc.time()-t1.nn

summary(donnees_freq_valid_echantillon$ClaimNb)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.00000 0.00000 0.00000 0.05181 0.00000 4.00000  

summary(freq.predict.nn)
#Min.   :0.006381  
#1st Qu.:0.031044  
#Median :0.043486  
#Mean   :0.052019  
#3rd Qu.:0.060611  
#Max.   :0.652210 

## Calcul des erreurs
freq.SE.nn <- sum((donnees_freq_valid_echantillon$ClaimNb - freq.predict.nn)^2)
freq.SE.nn
# 1184.862
freq.MSE.nn <- mean((donnees_freq_valid_echantillon$ClaimNb - freq.predict.nn)^2)
freq.MSE.nn
# 0.05510984
freq.RMSE.nn <- sqrt(freq.MSE.nn)
freq.RMSE.nn
# 0.2347549

#frequence moyenne
freq.mean.nn<-mean(freq.predict.nn)

#Affichage des resultats ensemble
freq.nn.results<-data.frame(freq.SE.nn,freq.MSE.nn,freq.RMSE.nn,FreqMoyenneHistorique,freq.mean.nn)
names(freq.nn.results)[1]<-"SE"
names(freq.nn.results)[2]<-"MSE"
names(freq.nn.results)[3]<-"RMSE"
names(freq.nn.results)[4]<-"Mean frequence"
names(freq.nn.results)[5]<-"Mean frequence estimee"
freq.nn.results
#SE        MSE      RMSE Mean frequence Mean frequence estimee
#1184.862 0.05510984 0.2347549     0.05181395             0.05201853

#Tous les resultats pour frequence #
freq<-rbind(freq.tree.results,freq.rf.results,freq.gbm.results,freq.XGboost.results,freq.nn.results)
freq.time<-c(t2.tree[1],t2.rf[1],t2.gbm[1],t2.XGboost[1],t2.nn[1])
freq_final=data.frame(Methode=c("CART","Random Forest","Gradient Boosting Machine","XGBoost","Neural Network"),freq,freq.time)


freq_final<-freq_final[order(freq_final$RMSE,decreasing = TRUE),]
View(freq_final)

########################################################################################
##########                          III. MODELES DE COUT                       ##########
########################################################################################

cout.mean.real<-mean(donnees_cout_attri_valid$ClaimAmount)
cout.mean.real
# 1140.385

###### III.1. ARBRE CART #######

## On determine la formule pour des arbres
t1.tree<-proc.time()
n2 <- names(donnees_cout)
fm3 <- as.formula(paste("ClaimAmount ~ ", paste(n2[!n2 %in% "ClaimAmount"], collapse = " + ")))
fm3

## Arbre maximal

cout.tree <- rpart(formula=fm3, data=donnees_cout_attri_app, method="anova", 
                   control = rpart.control(minsplit=1,minbucket=1,cp=0,maxcompete=2,xval=5))

#rpart.plot(freq.tree1)
cout.tree$cptable
plotcp(cout.tree)
# L'arbre maximal est de surapprentissage, donc il faut l'elaguer

## Arbre elague
cout.bestcp <- cout.tree$cptable[which.min(cout.tree$cptable[,"xerror"]),"CP"]

cout.tree.pruned <- prune(cout.tree, cp = cout.bestcp)
cout.tree.pruned
rpart.plot(cout.tree.pruned)




## Prediction
cout.predict.tree <- predict(cout.tree.pruned,donnees_cout_attri_valid)
t2.tree<-proc.time()-t1.tree

summary(donnees_cout_attri_valid$ClaimAmount)
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.09  626.70 1128.00 1140.00 1204.00 4762.00 

summary(cout.predict.tree)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1109    1109    1109    1144    1191    1191 

# On trouve que mean(y^) ~ mean (y) donc l'estimation de l'arbre CART est tres bonne

## Calcul des erreurs
cout.SE.tree <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.tree)^2)
cout.SE.tree
## 5215793951
cout.MSE.tree <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.tree)^2)
cout.MSE.tree
## 622930.1
cout.RMSE.tree <- sqrt(cout.MSE.tree)
cout.RMSE.tree
# 789.2592

#frequence moyenne 
cout.mean.tree<-mean(cout.predict.tree)

#Affichage des resultats ensemble
cout.tree.results<-data.frame(cout.SE.tree,cout.MSE.tree,cout.RMSE.tree,CoutMoyenHistorique,cout.mean.tree)
names(cout.tree.results)[1]<-"SE"
names(cout.tree.results)[2]<-"MSE"
names(cout.tree.results)[3]<-"RMSE"
names(cout.tree.results)[4]<-"Mean cout"
names(cout.tree.results)[5]<-"Mean cout estime"
cout.tree.results
#SE      MSE     RMSE CoutMoyenHistorique Mean cout estime
#5215793951 622930.1 789.2592       1140.385         1143.839


####### III.2. FORETS ALEATOIRES #######

## Contruction des forets
t1.rf<-proc.time()
cout.rf <- randomForest(fm3, data=donnees_cout_attri_app, num.trees=500, mtry=3, min.node.size=1)
summary(cout.rf)
plot(cout.rf)

# Apres 400 arbres, pas trop de changement en termes d'erreur

varImpPlot(cout.rf)
# Variable + important : Density + DrivAge

plot(cout.rf$mse)
cout.rf$mse
min(cout.rf$mse)
# nb d'arbre optimal = 500

max(treesize(cout.rf))
hist(treesize(cout.rf))
# nombre de noeuds max = 5424

#
mtry <- tuneRF(donnees_cout_attri_app[,-10],donnees_cout_attri_app[,10],ntreeTry=500,stepFactor=1,improve=0.05,trace=TRUE, plot=TRUE, doBest=FALSE)
mtry.opt <- mtry[,"mtry"][which.min(mtry[,"OOBError"])]
mtry.opt
# mtry optimal (minimise l'erreur) = 3

## Foret optimale
cout.rf.opt <- randomForest(fm3, data=donnees_cout_attri_app, ntree=500, mtry=3, nodesize=1)

##### Prediction
cout.predict.rf <- predict(cout.rf.opt,donnees_cout_attri_valid)
t2.rf<-proc.time()-t1.rf

summary(donnees_cout_attri_valid$ClaimAmount)
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.09  626.70 1128.00 1140.00 1204.00 4762.00  

summary(cout.predict.rf)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#341.7  1052.0  1151.0  1160.0  1249.0  2827.0  

## Calcul des erreurs
cout.SE.rf <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.rf)^2)
cout.SE.rf
## 5467364768
cout.MSE.rf <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.rf)^2)
cout.MSE.rf
## 652975.6
cout.RMSE.rf <- sqrt(cout.MSE.rf)
cout.RMSE.rf
# 808.0691

#frequence moyenne 
cout.mean.rf<-mean(cout.predict.rf)

#Affichage des resultats ensemble
cout.rf.results<-data.frame(cout.SE.rf,cout.MSE.rf,cout.RMSE.rf,CoutMoyenHistorique,cout.mean.rf)
names(cout.rf.results)[1]<-"SE"
names(cout.rf.results)[2]<-"MSE"
names(cout.rf.results)[3]<-"RMSE"
names(cout.rf.results)[4]<-"Mean cout"
names(cout.rf.results)[5]<-"Mean cout estime"
cout.rf.results
#SE      MSE     RMSE Mean cout Mean cout estime
#5467364768 652975.6 808.0691  1140.385          1159.69

####### III.3. GBM ####### 

## Training
t1.gbm<-proc.time()
 cout.gbm <- gbm(formula=fm3, data=donnees_cout_attri_app, 
                 n.trees=10000,
                 shrinkage=0.001,
                train.fraction = 0.75)


#cout.gbm<- mboost(formula = fm3, data = donnees_cout_attri_app,
#                 baselearner = "btree", family = GammaReg(), 
 #                control = boost_control(mstop = 100))

cout.gbm
summary(cout.gbm)

best.iter <- gbm.perf(cout.gbm,method="OOB")

## Prediction
cout.predict.gbm <- predict(cout.gbm,donnees_cout_attri_valid,type="response")
t2.gbm<-proc.time()-t1.gbm

summary(donnees_cout_attri_valid$ClaimAmount)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.09  626.70 1128.00 1140.00 1204.00 4762.00 

summary(cout.predict.gbm)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1068    1122    1145    1146    1168    1275

## Calcul des erreur
cout.SE.gbm <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.gbm)^2)
cout.SE.gbm
# 5202703426

cout.MSE.gbm <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.gbm)^2)
cout.MSE.gbm
# 621366.7
cout.RMSE.gbm <- sqrt(cout.MSE.gbm)
cout.RMSE.gbm
# 788.2682

#frequence moyenne
cout.mean.gbm<-mean(cout.predict.gbm)

#Affichage des resultats ensemble
cout.gbm.results<-data.frame(cout.SE.gbm,cout.MSE.gbm,cout.RMSE.gbm,CoutMoyenHistorique,cout.mean.gbm)
names(cout.gbm.results)[1]<-"SE"
names(cout.gbm.results)[2]<-"MSE"
names(cout.gbm.results)[3]<-"RMSE"
names(cout.gbm.results)[4]<-"Mean cout"
names(cout.gbm.results)[5]<-"Mean cout estime"
cout.gbm.results
#SE      MSE     RMSE Mean cout Mean cout estime
#5202703426 621366.7 788.2682  1140.385         1146.172

####### III.4. XGBOOST #######
t1.XGboost<-proc.time()
## Preparation
cout.XGboost.train.mf<- model.frame(fm3,donnees_cout_attri_app)
cout.XGboost.train.m<- model.matrix(attr(cout.XGboost.train.mf,"terms"),data=donnees_cout_attri_app)
cout.XGboost.train <- xgb.DMatrix(cout.XGboost.train.m,label=donnees_cout_attri_app$ClaimAmount)

cout.XGboost.test.mf<- model.frame(fm3,donnees_cout_attri_valid)
cout.XGboost.test.m<- model.matrix(attr(cout.XGboost.test.mf,"terms"),data=donnees_cout_attri_valid)
cout.XGboost.test <- xgb.DMatrix(cout.XGboost.test.m,label=donnees_cout_attri_valid$ClaimAmount)

# ## Parametres optimaux pour la fonction XGBoost
# params.cout.XGboost <- list(booster = "gbtree", objective = "reg:linear", eta=0.015,gamma=0, max_depth=10, min_child_weight=0, subsample=.5, colsample_bytree=.5,eval_metric='rmse',nthread=4,verbose=TRUE,seed=123)
# # 
# xgbcv <- xgb.cv( params = params.cout.XGboost, data = cout.XGboost.train, nrounds = 2000, stratified = T, print_every_n = 50, early_stop_rounds = 20, maximize = F,nfold = 5)

#xgbcv

#params.cout.XGboost

param1 <- list(
  "eval_metric" = "rmse"
  , "eta" = 0.01
  , "subsample" = 0.5
  , "colsample_bytree" = 0.5
  , "min_child_weight" = 0
  , "max_depth" = 10
  , "nthread"=4
)

## Training
cout.XGboost = xgb.train(nrounds=500, params=param1, data=cout.XGboost.train)

## Prediction
cout.predict.XGboost<-predict(cout.XGboost,cout.XGboost.test)
t2.XGboost<-proc.time()-t1.XGboost
summary(donnees_cout_attri_valid$ClaimAmount)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.09  626.70 1128.00 1140.00 1204.00 4762.00 

summary(cout.predict.XGboost)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#651.7  1055.0  1125.0  1134.0  1202.0  2181.0 

## Calcul des erreurs
cout.SE.XGboost <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.XGboost)^2)
cout.SE.XGboost
# 5267766758

cout.MSE.XGboost <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.XGboost)^2)
cout.MSE.XGboost
# 629137.3

cout.RMSE.XGboost <- sqrt(cout.MSE.XGboost)
cout.RMSE.XGboost
# 793.1818

#frequence moyenne
cout.mean.XGboost<-mean(cout.predict.XGboost)

#Affichage des resultats ensemble
cout.XGboost.results<-data.frame(cout.SE.XGboost,cout.MSE.XGboost,cout.RMSE.XGboost,CoutMoyenHistorique,cout.mean.XGboost)
names(cout.XGboost.results)[1]<-"SE"
names(cout.XGboost.results)[2]<-"MSE"
names(cout.XGboost.results)[3]<-"RMSE"
names(cout.XGboost.results)[4]<-"Mean cout"
names(cout.XGboost.results)[5]<-"Mean cout estime"
cout.XGboost.results
#SE      MSE     RMSE Mean cout Mean cout estime
#5267766758 629137.3 793.1818  1140.385         1134.397

####### III.5. RESEAUX DE NEURONES #######

t1.nn<-proc.time()
donnees_cout_attri_app1<-donnees_cout_attri_app[,c(which(colnames(donnees_cout_attri_app)=="VehAge"),
                                                   which(colnames(donnees_cout_attri_app)=="DrivAge"),
                                                   which(colnames(donnees_cout_attri_app)=="BonusMalus"),
                                                   which(colnames(donnees_cout_attri_app)=="Density"),
                                                   which(colnames(donnees_cout_attri_app)=="ClaimAmount"))
                                                ]
donnees_cout_attri_valid1<-donnees_cout_attri_valid[,c(which(colnames(donnees_cout_attri_valid)=="VehAge"),
                                                       which(colnames(donnees_cout_attri_valid)=="DrivAge"),
                                                       which(colnames(donnees_cout_attri_valid)=="BonusMalus"),
                                                       which(colnames(donnees_cout_attri_valid)=="Density"),
                                                       which(colnames(donnees_cout_attri_valid)=="ClaimAmount"))
                                                    ]
donnees_cout_attri_valid1<-as.matrix(sapply(donnees_cout_attri_valid1, as.numeric)) 

dataMeans<- apply(donnees_cout_attri_app1,2,mean);
dataSTDEV<- apply(donnees_cout_attri_app1,2,sd);
donnees_cout_attri_app_scale<- scale(donnees_cout_attri_app1);

#On fit le modele
Nfit <- neuralnet(ClaimAmount ~ VehAge+DrivAge+BonusMalus+Density, 
                  data=donnees_cout_attri_app_scale, hidden=1, threshold=0.01, stepmax=5000000)
ls(Nfit)

#on Predit 
claim_Predict<-neuralnet::compute(Nfit,as.data.frame(donnees_cout_attri_valid1[,1:4]))
table(claim_Predict$net.result)
plot(claim_Predict$net.result)

t2.nn<-proc.time()-t1.nn

#les predictions sont la
cout.predict.nn<-claim_Predict$net.result*dataSTDEV[5]+dataMeans[5]

cout.SE.nn <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.nn)^2)
cout.SE.nn

cout.MSE.nn <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.nn)^2)
cout.MSE.nn

cout.RMSE.nn <- sqrt(cout.MSE.nn)
cout.RMSE.nn


#frequence moyenne
cout.mean.nn<-mean(cout.predict.nn)

#Affichage des resultats ensemble
cout.nn.results<-data.frame(cout.SE.nn,cout.MSE.nn,cout.RMSE.nn,CoutMoyenHistorique,cout.mean.nn)
names(cout.nn.results)[1]<-"SE"
names(cout.nn.results)[2]<-"MSE"
names(cout.nn.results)[3]<-"RMSE"
names(cout.nn.results)[4]<-"Mean cout"
names(cout.nn.results)[5]<-"Mean cout estime"
cout.nn.results

#Tous les resultats pour le cout #
cout<-rbind(cout.tree.results,cout.rf.results,cout.gbm.results,cout.XGboost.results,cout.nn.results)
cout.time<-c(t2.tree[1],t2.rf[1],t2.gbm[1],t2.XGboost[1],t2.nn[1])
cout_final=data.frame(Methode=c("CART","Random Forest","Gradient Boosting Machine","XGBoost","Reseau de neurones"),cout,cout.time)


cout_final<-cout_final[order(cout_final$RMSE,decreasing = FALSE),]
View(cout_final)

########## TARIFICATION : meilleurs modeles ###################################
#CART pour frequence et cout 
rix1<-freq.mean.tree*cout.mean.tree
prix1
#61.58214
########## TARIFICATION : Agregation des modeles ##############################

###### frequence ########
freq.RMSE.total<-(freq.RMSE.tree+freq.RMSE.rf+freq.RMSE.gbm+freq.RMSE.XGboost+freq.RMSE.nn)
freq.poidss<-c(freq.RMSE.tree,freq.RMSE.rf,freq.RMSE.gbm,freq.RMSE.XGboost,freq.RMSE.nn)/freq.RMSE.total
freq.poids<-1/freq.poidss

freq.total<-(freq.predict.tree*freq.poids[1]+freq.predict.rf*freq.poids[2]+freq.predict.gbm*freq.poids[3]+freq.predict.XGboost*freq.poids[4]+freq.predict.nn*freq.poids[5])/sum(freq.poids)
frequence<-mean(freq.total)
frequence

#On verifie que le RMSE est plus petit pour le modele agrege
freq.RMSE.final<-sqrt(mean((donnees_freq_valid_echantillon$ClaimNb-freq.total)^2))
freq.RMSE.final

###### cout ########
#on choisit de ne pas agreger avec nnet car cela donne des mauvais resultats avec cette methode
cout.RMSE.total<-(cout.RMSE.tree+cout.RMSE.rf+cout.RMSE.gbm+cout.RMSE.XGboost)
cout.poidss<-c(cout.RMSE.tree,cout.RMSE.rf,cout.RMSE.gbm,cout.RMSE.XGboost)/cout.RMSE.total
cout.poids<-1/cout.poidss

cout.total<-(cout.predict.tree*cout.poids[1]+cout.predict.rf*cout.poids[2]+cout.predict.gbm*cout.poids[3]+cout.predict.XGboost*cout.poids[4])/sum(cout.poids)
cout<-mean(cout.total)
cout

#On verifie que le RMSE est plus petit pour le modele agrege
cout.RMSE.final<-sqrt(mean((donnees_cout_attri_valid$ClaimAmount-cout.total)^2))
cout.RMSE.final

#Affichage resultats agreges #####
resultat_aggregation<-data.frame(frequence_aggr=frequence,freq.RMSE.aggr=freq.RMSE.final,cout_aggr=cout,cout.RMSE.aggr=cout.RMSE.final,prix=frequence*cout)
resultat_aggregation
