package(datasets)

inputData <- read.csv("http://rstatistics.net/wp-content/uploads/2015/09/adult.csv")

head(inputData)
str(inputData)
View(inputData)
nrow(inputData)
ncol(inputData)
summary(inputData$AGE)

head(inputData)

table(inputData$ABOVE50K)

input_ones <- inputData[which(inputData$ABOVE50K == 1), ]  # all 1's

input_zeros <- inputData[which(inputData$ABOVE50K == 0), ]  # all 0's

nrow(input_zeros);nrow(input_ones)

set.seed(100)

library(smbinning)
# segregate continuous and factor variables
factor_vars <- c ("WORKCLASS", "EDUCATION", "MARITALSTATUS", "OCCUPATION", "RELATIONSHIP", "RACE", "SEX", "NATIVECOUNTRY")
continuous_vars <- c("AGE", "FNLWGT","EDUCATIONNUM", "HOURSPERWEEK", "CAPITALGAIN", "CAPITALLOSS")

required( smbinning)
version

iv_df <- data.frame(VARS=c(factor_vars, continuous_vars), IV=numeric(14))

for(factor_var in factor_vars){
  smb <- factor(trainingData, y="ABOVE50K", x=factor_var)  # WOE table
  if(class(smb) != "character"){ # heck if some error occured
    iv_df[iv_df$VARS == factor_var, "IV"] <- smb$iv
  }
  
  
  
}