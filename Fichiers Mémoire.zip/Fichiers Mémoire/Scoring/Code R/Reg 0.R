setwd("B:/ASSU-INT-AFI-ACT/Transversal/Stages/2018 M�moire Tabammout Afaf")
#data trouv�e sur github ( source initiale Insee

#https://github.com/juba/questionr/blob/master/data/hdv2003.RData)

library(questionr)
library(car) 
library(dplyr)
library(ggplot2)

data(hdv2003)

missmap(data, col=c("blue", "red"), legend=FALSE)
na.omit(data$sport)
data=hdv2003
head(hdv2003)
str(hdv2003)
attach(data)
names(data)
dim(data)
glimpse(data)


table(data$qualif)


plot(data$qualif)

table(data$sex)

plot(data$sex)
qplot(data$sex)
qplot(data$sex,colour = "cyl") # Nous constatons que nous avons plus de femmes que d'hommes

min(data$age)
max(data$age)

table(data$age)
hist(data$age)

summary(data$age)

length(data$age)
plot(data$age)

a=trunc((max(data$age)-min(data$age))/5)

b=0
for  (i in (1:4) ) {
b[i]=trunc(min(data$age)+i*a)
 
};


b[1]
b[2]
b[3]
b[4]
#Intervalles de largeurs (amplitudes) �gales

table(cut(data$age, c(18,33, 48,63, 78,97),include.lowest = TRUE))

#Avantages de cette m�thode



#Conservation de la distribution des donn�es (la densit� reste inchang�e)

# Kernel Density Plot
hist(data$age, # histogram
     col="peachpuff", # column color
     border="black",
     prob = TRUE, # show densities instead of frequencies
     xlab = "temp",
     main = "Beaver #1")
lines(density(data$age), # density plot
      lwd = 2, # thickness of line
      col = "chocolate3")

#Formule de Freedman-Diaconis


M=max(data$age) 

m=min(data$age)

methode=(M-m)/(2*25*(2000)^(-1/3))

methode

d=dist(data)

#CAH, m�thode de WARD
dendro <- hclust(d,method="ward.D2")

#affichage
plot(dendro)
             
summary(data$age)


q1=data$age[(2000/3)]
         
# M�thode quantile  on s'est bas� sur les quartiles pour faire notre r�partition


data$age=cut(data$age, c(18,35, 48,60,97),include.lowest = TRUE)

table(data$age)

qplot+ scale_colour_manual(values = c("red"))

ggplot(data, aes(x = age)) + geom_histogram(aes(y = ..count..), stat = "count",colour="#FF9999",
                                             binwidth = 1,fill="#FF9999",
                                             bins = 3,
                                             origin = 1,
                                             right = TRUE)
#D�terminer K

Broooks=5*log10(2000)

Huntsberger=1+3.332*log10(2000)

Sturges=log2(2001)
Max=97
Min=18
IQ=25
Scott= (97-18)/(2*25*2000^(-1/3))

std(data)

resultats<-data.frame(taille=c(185,178,165,171,172),poids=c(82,81,55,65,68))

  resultats<-data.frame(table(data$age),row.names=c("classe1","classe2","classe3","classe4"))
  
  
  hdv2003[,c("id","age")]
  
  b = subset(hdv2003, select = c(id, age))
  
  View(b)
  a=data.frame(b)
  
write.table(b, "C:\Users\x168165\Desktop\afaf.xlsm", col=NA, sep="\t",dec=".")

write.csv2(a, file="data.csv")

#classification: ( Plusieurs m�thodes sont d�j� impl�m�net�es) https://www.persee.fr/doc/espos_0755-7809_2000_num_18_1_1930
#http://www.info.univ-angers.fr/~gh/wstat/Discre/index.php?texte=
str(a)