require(ISLR)
names(Smarket)

head(Smarket)

summary(Smarket)

ncol(Smarket)
nrow(Smarket)

par(mfrow=c(1,5))
for(i in 1:5) {
  hist(Smarket[,i], main=names(Smarket)[i])
}
par(mfrow=c(1,5))
for(i in 1:5) {
  boxplot(Smarket[,i], main=names(Smarket)[i])
}

#???donn�es manquantes

library(Amelia)
library(mlbench)
missmap(Smarket, col=c("blue", "red"), legend=FALSE)

library(corrplot)
correlations <- cor(Smarket[,1:8])
corrplot(correlations, method="circle")