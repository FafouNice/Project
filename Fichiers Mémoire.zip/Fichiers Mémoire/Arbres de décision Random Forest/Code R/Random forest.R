#######  FORETS ALEATOIRES #######

## Contruction des forets

t1.rf<-proc.time()

Base.train$Localisation=as.factor(Base.train$Localisation)

str(Base.train)
# Random forest ne prend pas en consid�ration les variables cat�gorielles  avec  plus de 53 modalit�s

# il faut consid�rer cette �criture avec x test et y test pour que la m�thode prenne en charge 
rf <- randomForest(x=Base.train[,-c(1,4)],y=Base.train[,1],xtest=Base.train 
                   [,-c(1,4)],ytest=Base.train[ ,1], do.trace=5, ntree=1000) 


summary(rf)

plot(rf)

# Apres 1000  arbres, pas trop de changement en termes d'erreur

varImpPlot(rf)

# Variable + important : 

plot(rf$mse)
rf$mse
min(rf$mse)
# nb d'arbre optimal = 500

max(treesize(rf))
hist(treesize(rf))


# nombre de noeuds max = 5424

#
mtry <- tuneRF(donnees_cout_attri_app[,-10],donnees_cout_attri_app[,10],ntreeTry=500,stepFactor=1,improve=0.05,trace=TRUE, plot=TRUE, doBest=FALSE)
mtry.opt <- mtry[,"mtry"][which.min(mtry[,"OOBError"])]
mtry.opt
# mtry optimal (minimise l'erreur) = 3

## Foret optimale
cout.rf.opt <- randomForest(fm3, data=donnees_cout_attri_app, ntree=500, mtry=3, nodesize=1)

##### Prediction
cout.predict.rf <- predict(cout.rf.opt,donnees_cout_attri_valid)
t2.rf<-proc.time()-t1.rf

summary(donnees_cout_attri_valid$ClaimAmount)
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1.09  626.70 1128.00 1140.00 1204.00 4762.00  

summary(cout.predict.rf)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#341.7  1052.0  1151.0  1160.0  1249.0  2827.0  

## Calcul des erreurs
cout.SE.rf <- sum((donnees_cout_attri_valid$ClaimAmount - cout.predict.rf)^2)
cout.SE.rf
## 5467364768
cout.MSE.rf <- mean((donnees_cout_attri_valid$ClaimAmount - cout.predict.rf)^2)
cout.MSE.rf
## 652975.6
cout.RMSE.rf <- sqrt(cout.MSE.rf)
cout.RMSE.rf
# 808.0691

#frequence moyenne 
cout.mean.rf<-mean(cout.predict.rf)

#Affichage des resultats ensemble
cout.rf.results<-data.frame(cout.SE.rf,cout.MSE.rf,cout.RMSE.rf,CoutMoyenHistorique,cout.mean.rf)
names(cout.rf.results)[1]<-"SE"
names(cout.rf.results)[2]<-"MSE"
names(cout.rf.results)[3]<-"RMSE"
names(cout.rf.results)[4]<-"Mean cout"
names(cout.rf.results)[5]<-"Mean cout estime"
cout.rf.results
#SE      MSE     RMSE Mean cout Mean cout estime
#5467364768 652975.6 808.0691  1140.385          1159.69