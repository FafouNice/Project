setwd("B:/ASSU-INT-AFI-ACT/Transversal/Stages/2018 M�moire Tabammout Afaf")
#REG LINEAIRE MULTIPLE
install.packages("ggcorrplot")

library(microbenchmark)

library(FSelectorRcpp)

library(RWeka)

malad_coeur <- read.csv(file.choose(), header = TRUE, sep = ",")

head(malad_coeur)

str(malad_coeur)


attach(malad_coeur)

names(malad_coeur)

base = subset(malad_coeur, select = c(chd, age, tobacco, sbp, famhist, alcohol, 
                                       obesity, ldl, adiposity, typea))
head(base)# d�but de la base 
tail(base) # fin de la base 
summary(base)

head(base)

missmap(malad_coeur[,-1], col=c("blue", "red"), legend=FALSE)

correlations <- cor(malad_coeur[,c(-6,-1)])

corrplot(correlations, method="circle")


base$chd <- factor(base$chd)
summary(base)

na.omit(base)

attach(base)

#Analyse distributions 

par(mfrow=c(3,1))

hist(x = age, col = "orange", main = "Age", xlab = "", ylab = "")

hist(x = sbp, col = "blue", main = "pression sanguine ", xlab = "", 
     ylab = "")

hist(x = alcohol, col = "red", main = "Conso alcool", xlab = "", 
     ylab = "")

hist(x = tobacco, col = "violet", main = "tabac consomm� cumul", xlab = "", 
     ylab = "")

hist(x = ldl, col = "green2", main = "taux de cholesterol", xlab = "", ylab = "")

hist(x = obesity, col = "slategray", main = "Ob�sit�", xlab = "", ylab = "")

which(base$tobacco>=20)

base[115,]

base[c(115,162,187,407,411),]

#Les variables conso d'alcool et Qt� de tabac semblent �tre distribu�es de la m�me fa�on, de m�me que le taux de cholest�rol et l'ob�sit�.

#Un autre outil d'analyse est aussi de r�aliser des nuages de points pour toutes les vairiables. On peut �ventuellement colorer les points selon la variable cible


par(mfrow = c(1, 1))
pairs(base, col = base$chd)



par(mfrow = c(1, 2))
require(ggplot2)




#Discr�tisation  M�thode 1 

breaks_to_use <- quantile(malad_coeur$age, seq(0, 1, 0.25))
discretized_age <- cut(malad_coeur$age, breaks = breaks_to_use)
summary(malad_coeur$age)






p=qplot(alcohol, tobacco, data = base, facets = chd ~ .)+geom_point(color='purple')

p + theme(axis.title=element_text(face="bold.italic", 
                                  size="12", color="brown"), legend.position="top")



c(min=min(age),mean=mean(age),max=max(age))
str(age)
Breaksage=c(15,31,45,55,64) 
age.d=cut(age,breaks=Breaksage,include.lowest = TRUE)

table(age.d)

summary(age.d)
summary(age)

c(min=min(tobacco),mean=mean(tobacco),max=max(tobacco))
Breakstob = c(0, 0.05, 2, max(tobacco))
tobacco.d = cut(tobacco, breaks = Breakstob, include.lowest = TRUE)
summary(tobacco.d)
base2=cbind(base,age.d,tobacco.d)
require(dplyr)

detach(base)
attach(base2)



b = subset(base2, select = c(chd, age.d))
View(b)

xtabs(~chd + age.d, data = base2)
xtabs(~chd + tobacco.d, data = base2)
xtabs(~chd +famhist, data = base2)

base3 <- subset(x = base2, subset = (age > 15))
detach(base2)
attach(base3)
View(base3)

summary(base3$alcohol)
alcoholinterv=c(0,0.5,8,18,50,147)

alcohol.d=cut(base3$alcohol,breaks=alcoholinterv,include.lowest = TRUE)

table(alcohol.d)
xtabs(~chd + alcohol.d, data = base3)

#alcohol pas d'effect, m�me en augmentant la quantit� d'alcohol dans le sang on remarque que...
# On enl�ve dans la base de travail les variables age et tobacco
# continues, au profit des discr�tis�s
base3 <- subset(base3, select = -c(age, tobacco))


set.seed(111)

d = sort(sample(nrow(base3), nrow(base3) * 0.65))

# Echantillon d'apprentissage
appren <- base3[d, ]
# Echantillon de test
test <- base3[-d, ]
nrow(appren)
nrow(test)
nrow(base3)
nrow(base3)==nrow(test)+nrow(appren)

summary(appren)
summary(test)
attach(appren)
str(appren)
str(test)




# mod�le trivial r�duit � la constante
str_constant <- "~ 1"
# mod�le complet incluant toutes les explicatives potentielles
str_all <- "~sbp+famhist+alcohol+obesity+ldl+adiposity+typea+age.d+tobacco.d"

require(MASS)

modele <- glm(chd ~ 1, data = appren, family = binomial)


modele.forward <- step(modele, scope = list(lower = str_constant, upper = str_all), 
                          trace = TRUE, data = appren, direction = "forward")

summary(modele)

summary(modele.forward)

#Mod�le propos�: Call: glm(formula = chd ~ tobacco.d + famhist + age.d + typea + ldl + obesity + sbp, family = binomial, data = appren) retient toutes variables � l'exeption de la consommation d'alcool sans doute tr�s correl� avec la consommation du tabac 

aic <- function(reg){
  n <- nrow(reg$model)
  SCR <- sum(reg$residuals^2)
  p <- ncol(reg$model)-1
  resul <- n * log(SCR/n) + 2*(p+1)
  return(resul)
}
aic(modele.forward)
aic(modele)
# affichage du mod�le retenu


modele <- glm(chd ~ 1, data = appren, family = binomial)
modele.stepwise <- stepAIC(modele, scope = list(lower = str_constant, upper = str_all), 
                           trace = TRUE, data = appren, direction = "both")
summary(modele.stepwise)




logit = function(formula, lien = "logit", data = NULL) {
  glm(formula, family = binomial(link = lien), data)
}



m.logit <- logit(chd ~ sbp + famhist + obesity + ldl + adiposity + typea + age.d + 
                   tobacco.d, data = appren)
# r�sultats du mod�le logit
summary(m.logit)
exp(cbind(OR = coef(m.logit), confint(m.logit)))



m.logit
coef(m.logit)

cbind(coef(m.logit))



OR=exp(cbind(OR = coef(m.logit)))

# On peut conclure que le fait d'avoir un ant�c�dent dans la famille
#augmente le fait d'avoir une maladie cardique

summary(m.logit)
attributes(m.logit)


##################Validation du mod�le######################


# En logistique on s'int�resse aux r�sidus  de d�viance

par(mfrow = c(1, 1))
plot(rstudent(m.logit), type = "p", cex = 0.5, ylab = "R�sidus studentis�s ", 
     col = "springgreen2", ylim = c(-3, 3))
abline(h = c(-2, 2), col = "red")

#l'�cart de degr� de libert� entre le mod�le r�duit � la cste et le mod�le retenu donne la significativit� globale du mod�le.

(chi2 <- with(m.logit, null.deviance - deviance))

(ddl <- with(m.logit, df.null - df.residual))

(pvalue <- pchisq(chi2, ddl, lower.tail = F))


appren.p <- cbind(appren, predict(m.logit, newdata = appren, type = "link", 
                                  se = TRUE))
head(appren.p)

tail(appren.p)

appren.p <- within(appren.p, {
  PredictedProb <- plogis(fit)
  LL <- plogis(fit - (1.96 * se.fit))
  UL <- plogis(fit + (1.96 * se.fit))
})
tail(appren.p)

View(appren.p)

appren.p <- cbind(appren.p, pred.chd = factor(ifelse(appren.p$PredictedProb > 
                                                       0.5, 1, 0)))
head(appren.p)

View(appren.p)

predvsreal=data.frame(appren.p$pred.chd,appren.p$chd)

goodpredict=appren.p[which(appren.p$pred.chd==appren.p$chd),]

badpredict=appren.p[which(appren.p$pred.chd!=appren.p$chd),]

nrow(badpredict)

nrow(goodpredict)

errreur_pred=(nrow(badpredict)/(nrow(badpredict)+nrow(goodpredict)))*100

# Matrice de confusion
(m.confusion <- as.matrix(table(appren.p$pred.chd, appren.p$chd)))

m.confusion <- unclass(m.confusion)
# Taux d'erreur
Tx_err <- function(y, ypred) {
  mc <- table(y, ypred)
  error <- (mc[1, 2] + mc[2, 1])/sum(mc)
  print(error)
}
Tx_err(appren.p$pred.chd, appren.p$chd)


ma=table(pred=appren.p$pred.chd, chd=appren.p$chd)
sum(ma)
nrow(appren.p[which(appren.p$pred.chd==0),])
nrow(appren.p[which(appren.p$pred.chd==1),])
nrow(appren.p[which(appren.p$chd==0),])
nrow(appren.p[which(appren.p$chd==1),])

#1 ECHANTILLON TEST 
test.p <- cbind(test, predict(m.logit, newdata = test, type = "response", se = TRUE))
test.p <- cbind(test.p, pred.chd <- factor(ifelse(test.p$fit > 0.5, 1, 0)))
(m.confusiontest <- as.matrix(table(test.p$pred.chd, test.p$chd)))



m.confusiontest <- unclass(m.confusiontest)
# calcul du taux d'erreur sur l'�chantillon test
Tx_err(test.p$pred.chd, test.p$chd)

require(ROCR)

Pred = prediction(appren.p$PredictedProb, appren.p$chd)
Perf = performance(Pred, "tpr", "fpr")
plot(Perf, colorize = TRUE, main = "ROC apprentissage")

perf <- performance(Pred, "auc")
perf@y.values[[1]]
Predtest = prediction(test.p$fit, test.p$chd)
Perftest = performance(Predtest, "tpr", "fpr")
perftest <- performance(Predtest, "auc")
perftest@y.values[[1]]
par(mfrow = c(1, 2))
plot(Perf, colorize = TRUE, main = "ROC apprentissage - AUC= 0.8")
plot(Perftest, colorize = TRUE, main = "ROC Test - AUC =0.75 ")

                                                                                                                  
#-------------------------------------------fIN-------------------------
  


cbind(coef(m.logit))

min(cbind(coef(m.logit)))

frame=data.frame(coef=cbind(coef(m.logit)))


